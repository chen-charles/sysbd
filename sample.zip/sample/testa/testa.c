#define __INCLUDED_TEST__

#ifndef __INCLUDED_TEST__
#include	"causing_error.h"
#endif
